/**
 * Bridge from the roubaai settings page to the media providers: resolve the
 * provider one category currently uses (its API key, endpoint base, and
 * default model) out of the settings namespace the `@roubaai/settings` page
 * owns.
 *
 * Reads are PER OPERATION and OPTIONAL in every direction: a deployment
 * without the settings service, without the plugin, or with an unreadable
 * document falls straight through to the built-in category defaults (endpoint
 * and model) and lets the caller continue to its credential store and
 * environment. That is why the service is reached through `ctx.get` rather
 * than an `inject` entry — providers must keep loading on surfaces that carry
 * no settings service.
 *
 * The built-in fallbacks mirror the providers' own runtime constants
 * (`@roubaai/media-maizi` and `@roubaai/media-mxapi`); the settings page's
 * browser half carries a synced copy so its display agrees with what runs.
 * @module @roubaai/media/settings-lookup
 */
import type { Context } from '@deepseek-ai/cordis';
/** One media category the settings page manages. */
export type MediaSettingsCategory = 'image' | 'video' | 'music';
/** One provider configuration as the providers consume it. */
export interface ActiveMediaProvider {
    /** The provider in use's API key; absent when unset (callers fall back). */
    apiKey?: string;
    /** Endpoint base override from the settings page; absent when unset. */
    baseUrl?: string;
    /** Default model override from the settings page; absent when unset. */
    model?: string;
}
/**
 * Resolve the provider one category currently uses. Overrides come back
 * absent when unset, so each consumer keeps its own fallback priority
 * (settings page → deployment config → built-in default).
 * @param ctx - the plugin context (the settings service is optional).
 * @param namespace - the settings namespace the settings page owns.
 * @param category - which category's active provider to resolve.
 * @returns the key and overrides; every field absent when unconfigured.
 */
export declare function readActiveMediaProvider(ctx: Context, namespace: string, category: MediaSettingsCategory): ActiveMediaProvider;
//# sourceMappingURL=settings-lookup.d.ts.map