---
description: "Web 客户端的 Rouba DSH 品牌占位者：说明侧栏与会话首屏品牌插槽如何通过一套声明感知的注册集合获得 Rouba 标志与名称。"
kind: "package-reference"
---

# @deepseek-ai/dsh-client-ui-brand-rouba

[English](README.md) | 中文

## 概述

`dsh-client-ui-brand-rouba` 用 Rouba DSH 品牌填充通用浏览器品牌插槽——`sidebar.brand.mark`、`sidebar.brand.name` 与 `conversation.hero.brand.mark`。它无条件注册占位者：挂载本插件的部署即 Rouba 品牌化。官方的 `dsh-client-ui-brand-official` 占位者只在客户端以 `DSH_CLIENT_BUILD_PROFILE=official` 构建时注册，因此在普通 Rouba 构建中二者不会冲突；而以 official profile 构建却仍挂载本包的部署，会在 `single` 品牌插槽上注册两个占位者，必须禁用其中一行。当 Web 界面需要展示 Rouba 标志与名称时选择本包。

## 目录

- [使用本包](#use-this-package)
- [了解实现](#understand-the-implementation)
- [延伸阅读](#further-exploration)
- [模型体验](#model-experience)
- [已知限制与未决工作](#known-limitations-and-deferred-work)
- [开发备注](#dev-note)

-----

<a id="use-this-package"></a>
## 使用本包

把本包作为 web-app 组合中的浏览器 roster 行挂载；node 半身是空 Loader 席位，浏览器半身在客户端激活时注册占位者。

```yaml
- id: roubaai-brand
  name: '@deepseek-ai/dsh-client-ui-brand-rouba'
```

在本仓库的 web-app bundle 中，该行已与官方占位者并列发布。以 official profile 构建客户端（`DSH_CLIENT_BUILD_PROFILE=official`）却保留本行的部署，必须禁用 `ui-brand-official` 行（或本行），否则两者会注册到同一个 `single` 品牌插槽上。

### 占位者覆盖

| 插槽 | 占位者 |
|---|---|
| `sidebar.brand.mark` | `RoubaBrandMark` |
| `sidebar.brand.name` | `RoubaBrandName` |
| `conversation.hero.brand.mark` | `RoubaBrandMark` |

浏览器标题属于本包之外的构建环境关注点（`DSH_CLIENT_TITLE`）。

-----

<a id="understand-the-implementation"></a>
## 了解实现

<details>
<summary>实现内部 — 点击展开</summary>

本节解释品牌包背后的设计取舍；可观察行为已由[使用本包](#use-this-package)完整覆盖。

### 设计思路

三个占位者通过嵌套的 `ctx.slots.inject()` 调用作为一套声明感知的注册集合安装。因此无论本行在侧栏与对话声明者之前还是之后激活，本包都能工作；任一声明坍缩时它会撤销全部占位者，HMR 期间不会留下部分品牌混合。它不保留任何运行时状态。

### 源文件地图

| 文件 | 职责 |
|---|---|
| [`src/index.ts`](src/index.ts) | Node 半身插件入口：空 Loader 席位 |
| [`src/client/index.ts`](src/client/index.ts) | 覆盖品牌插槽的浏览器半身注册集合 |
| [`src/client/Brand.tsx`](src/client/Brand.tsx) | `RoubaBrandMark` 与 `RoubaBrandName` 占位者 |

### Profile 门控

官方占位者以 `DSH_CLIENT_BUILD_PROFILE === 'official'` 门控自身注册，因此两个包按构建 profile 互斥，而非靠运行时检查。Rouba 无条件注册，因为 Rouba 品牌化部署的每个构建都不是 official。

</details>

-----

<a id="further-exploration"></a>
## 延伸阅读

当包级契约还不够时阅读以下页面。

- [dsh-client-ui-brand-official](../ui-brand-official/README.zh.md) — 在 Rouba 构建中被本包顶替的官方占位者。
- [dsh-client-ui-sidebar](../ui-sidebar/README.zh.md) — 消费侧栏品牌插槽的界面。
- [dsh-client-ui-conversation](../ui-conversation/README.zh.md) — 消费会话首屏品牌插槽的界面。

-----

<a id="model-experience"></a>
## 模型体验

无，因为本包只贡献浏览器展示；这里没有任何东西到达模型请求。

#### KV Cache 影响

无；本包既不组装也不发送提供商请求。

## 已知限制与未决工作

<a id="known-limitations-and-deferred-work"></a>

以下限制界定本包何时不适用或需要特殊运维。它们是当前包约束。

- **本包只提供一套占位者** — 不同于共享鱼形标志的专属 Rouba 标志，应放在后续迭代或兄弟占位者包中。
- **浏览器标题独立** — `DSH_CLIENT_TITLE` 在构建时选择标题文本，而非经由 UI 插槽。
- **一个插槽不能容纳两个占位者** — 同时保留两个品牌行的 official profile 构建必须禁用其一，因为每个 `single` 插槽至多容纳一个占位者。

<a id="dev-note"></a>
### 开发备注

<details>
<summary>维护者工作上下文 — 点击展开</summary>

无。

</details>
