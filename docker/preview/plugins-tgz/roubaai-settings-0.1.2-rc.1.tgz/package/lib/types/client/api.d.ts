/**
 * Typed `fetch` wrapper over the plugin's fenced JSON route. Every call posts
 * to `<API_PREFIX>/<method>` and returns the envelope's `value`; a non-ok
 * envelope or a transport failure surfaces as {@link RoubaaiApiError} carrying
 * the wire code, so the settings surface can show the reason inline instead of
 * failing silently.
 * @module @roubaai/video-settings/client/api
 */
import type { SettingsView, TestResult } from '../shared.ts';
/** The host route prefix (kept in sync with the host half's `API_PREFIX`). */
export declare const API_PREFIX = "/api/roubaai-video";
/** One wire failure. */
export declare class RoubaaiApiError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
/** The route surface used by the settings section. */
export declare const api: {
    /** Read the redacted configuration and its revision. */
    settingsGet: () => Promise<SettingsView>;
    /**
     * Merge a patch into the configuration.
     * @param patch - partial settings (a `secret` field is written, never read back here).
     * @param expectedRevision - the revision the caller read; a namespace that
     * moved past it is refused so a concurrent edit is never overwritten.
     */
    settingsUpdate: (patch: Record<string, unknown>, expectedRevision?: number) => Promise<SettingsView>;
    /**
     * Probe the endpoint with the stored configuration, optionally applying a
     * patch first (so a just-typed key is verified before it is trusted).
     * @param patch - optional settings to save before probing.
     */
    test: (patch?: Record<string, unknown>) => Promise<TestResult>;
};
//# sourceMappingURL=api.d.ts.map