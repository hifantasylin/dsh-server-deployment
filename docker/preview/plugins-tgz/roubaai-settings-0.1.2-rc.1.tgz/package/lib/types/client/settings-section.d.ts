/**
 * "Video generation" settings section: the provider configuration for the
 * MaiziAI media providers, rendered natively in the DSH Settings shell.
 *
 * Reads and writes go through the plugin's own fenced settings route, never
 * the generic settings RPC: a third-party namespace is not served to
 * configuration clients by that domain. The section mirrors the DSH settings
 * recipe — one container card per group, title/description left and the
 * control right, hairline separators — and keeps three properties the shell
 * depends on:
 *
 *  - the API key is WRITE-ONLY. The route returns the redacted value, so the
 *    key never exists in this component's state after a save; the input shows
 *    a "saved" placeholder instead, and an untouched input is omitted from the
 *    patch so saving other fields cannot clear it;
 *  - writes are revision-guarded. The revision the last read returned is sent
 *    back, so a concurrent edit from another surface is refused (and reported)
 *    instead of being silently overwritten;
 *  - a failure is inline. A broken route or a refused write shows a line under
 *    the controls and reverts nothing optimistically — the form never claims a
 *    save it did not make.
 *
 * "Test connection" probes the endpoint with what the user is currently
 * looking at (saving the draft first) rather than with the last committed
 * value, so a key can be verified in the same breath it is typed.
 * @module @roubaai/video-settings/client/settings-section
 */
import { type JSX } from 'react';
import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Full section props: the settings shell's runtime share. */
export type RoubaaiVideoSettingsSectionProps = PropsRuntime<'settings.section'>;
/**
 * Render the provider configuration section.
 * @param _props - the settings shell's runtime share (unused: this section
 * reads its state from the plugin's own route).
 * @returns the section element tree.
 */
export declare function RoubaaiVideoSettingsSection(_props: RoubaaiVideoSettingsSectionProps): JSX.Element;
//# sourceMappingURL=settings-section.d.ts.map