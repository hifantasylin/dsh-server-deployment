/**
 * Dictionaries for the settings section. The plugin follows the browser's
 * language preference through `navigator.language`: the two dictionaries are
 * keyed identically and `t()` picks one, falling back to English for any
 * language the pair does not cover.
 *
 * Deliberately dependency-free — no locale service, no registration order to
 * get right — because this surface ships four labels and one status line. A
 * deployment that needs a third language swaps this module, not the section.
 * @module @roubaai/video-settings/client/locales
 */
/** The dictionary key union: both languages carry exactly these keys. */
declare const zh: {
    readonly intro: "配置 MaiziAI 视频/图片生成服务的连接信息。API Key 只写入、不回显。";
    readonly apiKeyTitle: "API Key";
    readonly apiKeyDesc: "MaiziAI 平台密钥，保存后不再显示";
    readonly apiKeySaved: "已保存，留空表示不修改";
    readonly apiKeyUnset: "尚未设置";
    readonly baseUrlTitle: "接口地址";
    readonly baseUrlDesc: "留空使用官方默认端点";
    readonly imageModelTitle: "图片模型";
    readonly imageModelDesc: "留空使用 provider 默认模型";
    readonly videoModelTitle: "视频模型";
    readonly videoModelDesc: "留空使用 provider 默认模型";
    readonly save: "保存";
    readonly saving: "保存中…";
    readonly test: "测试连接";
    readonly testing: "测试中…";
    readonly saveFailed: "保存失败：";
    readonly testFailed: "测试失败：";
    readonly conflict: "配置已被其他端修改，请刷新后重试。";
};
type MessageKey = keyof typeof zh;
/**
 * Look up one message in the active language.
 * @param key - the dictionary key.
 * @returns the localized string.
 */
export declare function t(key: MessageKey): string;
export {};
//# sourceMappingURL=locales.d.ts.map