/**
 * Host half of `@roubaai/video-settings`: owns the provider-configuration
 * settings namespace and serves it to the Web configuration surface through
 * the plugin's own fenced JSON route.
 *
 * The namespace is registered HERE, in the host plane, for two reasons: the
 * registration is then a process-wide singleton (an agent preset's isolated
 * realm registers and unregisters per session, which would make a settings
 * namespace flicker with the session lifecycle), and the write path stays on
 * the same plane as the settings document it persists to.
 *
 * The route exists because the DSH settings RPC domain serves only allowlisted
 * namespaces to configuration clients: a third-party namespace reaches its own
 * browser surface through a fenced route that calls the settings seam
 * in-process. Reads are always redacted (`apiKey` never crosses the wire);
 * writes are revision-guarded so a stale editor is refused instead of silently
 * overwriting a concurrent change.
 * @module @roubaai/video-settings
 */
import type { Context } from '@deepseek-ai/cordis';
import { type ResolvedRoubaaiVideoSettings } from './config.ts';
/**
 * Stable Cordis plugin name. Intentionally NOT the settings namespace: the
 * namespace (`ROUBAAI_SETTINGS_NS`) is the data contract the media providers
 * read, so it stays put even when this package's npm name changes.
 */
export declare const name = "roubaai-settings";
/** Services required before the namespace and its route can be mounted. */
export declare const inject: string[];
/** The JSON API prefix (`POST <prefix>/<method>`). */
export declare const API_PREFIX = "/api/roubaai-video";
/**
 * Probe the provider endpoint with the configured key: one `GET /models` on
 * the OpenAI-compatible base. It is the cheapest request that still proves
 * both halves of the configuration — the endpoint answers, and the key is
 * accepted — without spending a generation.
 *
 * @param settings - the resolved configuration to probe with.
 * @returns whether the provider answered favorably, plus the human reason.
 */
export declare function testConnection(settings: ResolvedRoubaaiVideoSettings): Promise<{
    ok: boolean;
    message: string;
}>;
/**
 * Register the provider-configuration namespace and mount its fenced JSON
 * route.
 *
 * Three methods share the prefix: `settings.get` (redacted view + revision),
 * `settings.update` (revision-guarded patch), and `test` (an endpoint probe
 * against the currently stored configuration, optionally after applying a
 * patch first so a just-typed key can be verified before it is trusted).
 * @param ctx - plugin context carrying the webServer and settings services.
 */
export declare function apply(ctx: Context): void;
declare const _default: {
    name: string;
    inject: string[];
    apply: typeof apply;
};
export default _default;
//# sourceMappingURL=index.d.ts.map