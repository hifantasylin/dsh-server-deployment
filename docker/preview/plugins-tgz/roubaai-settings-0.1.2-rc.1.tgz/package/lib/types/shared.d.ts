/**
 * Dependency-free half of the plugin's configuration contract: the namespace
 * id, the settings shape, and the wire view the fenced route returns.
 *
 * This module exists so the CLIENT bundle can import the contract without
 * pulling in `schemastery` — a schema library is a host-side concern and has
 * no business in a browser bundle (`verify-client-bundle-purity` refuses it).
 * `config.ts` layers the schema on top of this file; the browser half imports
 * only this one.
 * @module @roubaai/video-settings/shared
 */
/** The user-settings namespace holding the provider configuration. */
export declare const ROUBAAI_SETTINGS_NS = "roubaai-video-plugin";
/** Empty string means "unset": the consumer falls back to its own default. */
export declare const UNSET = "";
/** Endpoint base used when `baseUrl` is unset (the public MaiziAI API). */
export declare const DEFAULT_BASE_URL = "https://www.maizitech.xyz/v1";
/** User-facing provider configuration. */
export interface RoubaaiVideoSettings {
    /** MaiziAI API key; a `secret` role field, never returned over the wire. */
    apiKey: string;
    /** Endpoint base override; empty uses the provider's public default. */
    baseUrl: string;
    /** Default image model id; empty uses the provider's default. */
    imageModel: string;
    /** Default video model id; empty uses the provider's default. */
    videoModel: string;
}
/** Fully defaulted provider settings (every field present and a string). */
export type ResolvedRoubaaiVideoSettings = {
    readonly [K in keyof RoubaaiVideoSettings]: string;
};
/** The default settings: nothing configured, so every consumer falls back. */
export declare const ROUBAAI_SETTINGS_DEFAULTS: ResolvedRoubaaiVideoSettings;
/**
 * Narrow one resolved settings value into the fully defaulted shape. A
 * namespace the schema has already validated still needs this: an old
 * document (or one edited by hand) may omit a field the schema defaults only
 * at resolve time, and every consumer below would rather read `''` than
 * branch on `undefined`.
 * @param value - the resolved namespace value (untrusted shape).
 * @returns every field present as a string.
 */
export declare function resolveRoubaaiVideoSettings(value: unknown): ResolvedRoubaaiVideoSettings;
/** One schema-declared secret slot, as the redacted descriptor reports it. */
export interface SettingsSecretView {
    /** Path from the section root to the removed field. */
    path: string[];
    /** Whether the slot currently holds a value; the value itself never rides. */
    set: boolean;
}
/**
 * The view the fenced route returns for a read or a write: the redacted value
 * (`apiKey` absent), the revision a following write must echo, and the secret
 * slots so the form can show "已保存" without ever receiving the key.
 */
export interface SettingsView {
    /** Redacted resolved value. */
    value: unknown;
    /** Monotonic revision of the user section; echo it on the next write. */
    revision?: number;
    /** Every schema-declared secret slot with its configured state. */
    secrets: SettingsSecretView[];
}
/** One connection-test result. */
export interface TestResult {
    /** Whether the endpoint answered and accepted the key. */
    ok: boolean;
    /** Human-readable outcome (status, or why the probe failed). */
    message: string;
}
//# sourceMappingURL=shared.d.ts.map