/**
 * Serializable configuration for the roubaai video plugin: the user-facing
 * provider settings a deployment edits on the Settings page (MaiziAI API key,
 * endpoint base, and the default image/video models) rather than through
 * environment variables or the process-wide credential store.
 *
 * The schema is the SINGLE source of truth for three consumers: the settings
 * namespace registration (which validates and resolves defaults), the
 * configuration surface (which renders one row per field, secret slots as
 * write-only inputs), and the Maizi provider (which reads the resolved value
 * before falling back to credentials/env).
 *
 * The dependency-free half of the contract lives in `shared.ts` so the browser
 * bundle imports the shape without the schema library; this file layers the
 * schemastery schema on top and re-exports the rest unchanged.
 * @module @roubaai/video-settings/config
 */
import z from '@deepseek-ai/schemastery';
import { type RoubaaiVideoSettings } from './shared.ts';
export * from './shared.ts';
/**
 * Schemastery schema for the provider configuration.
 *
 * `apiKey` carries `role('secret')`: the settings service strips it from every
 * `describe({ redactSecrets: true })` response and reports only whether the
 * slot is set, so the key is write-only from the browser's point of view. The
 * remaining default to the empty string, which every consumer reads as "not
 * configured, use your own default" — a meaningful, storable value.
 */
export declare const RoubaaiVideoSettingsSchema: z<RoubaaiVideoSettings>;
//# sourceMappingURL=config.d.ts.map